package clean.cleanarchitecture;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CleanArchitectureApplicationTests {

	@Test
	void contextLoads() {
	}

}
